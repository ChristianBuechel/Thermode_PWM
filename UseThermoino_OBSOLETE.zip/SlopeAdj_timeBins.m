function [optROR,complexTC] = SlopeAdj_timeBins(varargin)

    ovrROR      = NaN;
    ovrMsROR    = NaN;
    if ~nargin % provide some default values
        load('example_sine.mat');
        tC = example_sine;
        binSize     = 500; % the time (ms) in which the proportion of temperature change in every bin has to occur
        eT          = 40; % entry temp
        maxTOffs    = 2; % offset from entry temperature, i.e. the range to which the time course will be rescaled
    else
        tC = varargin{1};
        binSize = varargin{2};
        eT = varargin{3}; % entry temp
        maxTOffs = varargin{4}; % offset from entry temperature    
    end    
    if nargin==5 % then we have a fixed ROR we want to apply
        ovrROR = varargin{5}; % OVERRIDE rate of rise (�C/s)
        ovrMsROR = ovrROR/1e3; % OVERRIDE rate of rise (�C/ms)
    end

    % shift and rescale time course, obtain temporal derivative
    cTC = tC-tC(1); % "center" to entry temp
    scF = maxTOffs/max(cTC); % scaling factor
    adjTC = eT+cTC*scF; % adjusted ("centered" to baseline temp, rescaled to offset) 
    dAdjTC = diff(adjTC); % �C to cover in time bin

    % determine optimal rate of rise
    if isnan(ovrROR)
        optROR = max(dAdjTC*(1000/binSize));
        optROR = ceil(optROR*10)/10; % round up to .1� precision
        optMsROR = optROR/1e3;
    else
        optROR = ovrROR;
        optMsROR = ovrMsROR;
    end

    % scale dAdjTC to optROR (in milliseconds)
    complexTC = dAdjTC/optMsROR;

