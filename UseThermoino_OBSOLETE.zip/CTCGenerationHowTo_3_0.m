% for more complex example
load('example_sine.mat');

tC = example_sine; % time course in real �C (relative to eT), one entry is one bin

binSize     = 500; % the time (ms) in which the proportion of temperature change in every bin has to occur
eT          = 32; % entry temp
maxTOffs    = 2; % offset from entry temperature, i.e. the range to which the time course will be rescaled

[optROR,cTC] = SlopeAdj_timeBins(tC,binSize,eT,maxTOffs,15); % argument 5 fixes the rise rate; cTC will be the ms (of binSize) that thermode will heat/or cool
[optROR,cTC] = SlopeAdj_timeBins(tC,binSize,eT,maxTOffs,1); % argument 5 fixes the rise rate; cTC will be the ms (of binSize) that thermode will heat/or cool
cTC = ceil(cTC); % only integers!

figure;
subplot(2,1,1);
plot(tC);
title('Intended stimulation');
xlabel('Time');
ylabel('Temperature');

subplot(2,1,2);
plot(cTC);
title('Derived Thermode impulses');
xlabel('Time (chunk)');
ylabel('ms to open channel (negative=temp decrease)');

% Initialize Arduino
UseThermoino('Kill');
UseThermoino('Init','COM5',115200,32,15); % OR WHATEVER COM PORT YOUR THERMOINO 3.0 IS AT

% THERMOINO: Execute cTC (now contains lead in + w/m + lead out))
UseThermoino('InitCTC',binSize,1); % note: this assumes 500ms bins for the CTC
UseThermoino('LoadCTC',cTC,1);

report = UseThermoino('QueryCTC',3,1)
% report{4} should be identical to cTC

UseThermoino('Trigger'); % start stimulus
[~] = UseThermoino('ExecCTC',sum(cTC)); %Thermoino is now busy

% do your own MATLAB stuff here

UseThermoino('FlushCTC');
